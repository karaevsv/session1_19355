﻿using LangaugeDesktopApp.Data;

namespace LangaugeDesktopApp.Classes;

public static class Help
{
    public static TestdbContext DB = new TestdbContext();
}