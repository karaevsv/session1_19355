using System.Linq;
using Avalonia.Controls;
using LangaugeDesktopApp.Classes;
using Microsoft.EntityFrameworkCore;

namespace LangaugeDesktopApp.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        LoadData();
    }

    private void LoadData()
    {
        Help.DB.Clients.Load();
        if (string.IsNullOrEmpty(FindTb.Text))
        {
            MainDg.ItemsSource = Help.DB.Clients.ToList();
        }
        else
        {
            MainDg.ItemsSource = Help.DB.Clients.Where(el => el.FirstName.Contains(FindTb.Text) || 
                                                             el.LastName.Contains(FindTb.Text) ||
                                                             el.Patronymic.Contains(FindTb.Text) ||
                                                             el.Email.Contains(FindTb.Text) ||
                                                             el.Phone.Contains(FindTb.Text)).ToList();
        }
    }

    private void FindTb_OnTextChanged(object? sender, TextChangedEventArgs e)
    {
        LoadData();
    }
}