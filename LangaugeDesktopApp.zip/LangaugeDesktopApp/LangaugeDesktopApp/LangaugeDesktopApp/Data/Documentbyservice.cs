﻿using System;
using System.Collections.Generic;

namespace LangaugeDesktopApp.Data;

public partial class Documentbyservice
{
    public int Id { get; set; }

    public int ClientServiceId { get; set; }

    public string DocumentPath { get; set; } = null!;

    public virtual Clientservice ClientService { get; set; } = null!;
}
