﻿using System;
using System.Collections.Generic;

namespace LangaugeDesktopApp.Data;

public partial class Servicephoto
{
    public int Id { get; set; }

    public int ServiceId { get; set; }

    public string PhotoPath { get; set; } = null!;

    public virtual Service Service { get; set; } = null!;
}
