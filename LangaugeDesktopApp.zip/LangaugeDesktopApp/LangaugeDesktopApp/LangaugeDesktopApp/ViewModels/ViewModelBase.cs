﻿using ReactiveUI;

namespace LangaugeDesktopApp.ViewModels;

public class ViewModelBase : ReactiveObject
{
}